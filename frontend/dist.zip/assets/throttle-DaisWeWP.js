function i(o,e){let t=0;return function(...a){const n=Date.now();n-t>=e&&(t=n,o.apply(this,a))}}export{i as t};
